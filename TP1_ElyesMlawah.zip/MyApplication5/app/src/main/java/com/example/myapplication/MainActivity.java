package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button bConvert;
    private EditText editTextAmount;
    private TextView textViewResult;
    private RadioGroup radioGroup;
    private RadioButton radioButtonDinarToEuro, radioButtonEuroToDinar;

    private static final double DINAR_TO_EURO_RATE = 0.30;
    private static final double EURO_TO_DINAR_RATE = 3.33;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.bConvert = (Button) findViewById(R.id.b_convert);
        this.editTextAmount = findViewById(R.id.editTextText);
        this.textViewResult = findViewById(R.id.textView2);
        this.radioGroup = findViewById(R.id.radioGroup);
        this.radioButtonDinarToEuro = findViewById(R.id.radioButton_dinar_to_euro);
        this.radioButtonEuroToDinar = findViewById(R.id.radioButton_euro_to_dinar);

        bConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
    }

    private void convert() {
        String amountString = editTextAmount.getText().toString();

        if (amountString.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter an amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double amount = Double.parseDouble(amountString);
            double result;

            if (radioButtonDinarToEuro.isChecked()) {
                result = amount * DINAR_TO_EURO_RATE;
                textViewResult.setText(String.format("Result: %.2f Euros", result));
            } else if (radioButtonEuroToDinar.isChecked()) {
                result = amount * EURO_TO_DINAR_RATE;
                textViewResult.setText(String.format("Result: %.2f Dinars", result));
            } else {
                Toast.makeText(MainActivity.this, "Please select a conversion option", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid input format", Toast.LENGTH_SHORT).show();
        }
    }
}
